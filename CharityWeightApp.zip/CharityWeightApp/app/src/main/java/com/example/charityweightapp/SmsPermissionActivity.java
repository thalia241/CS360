package com.example.charityweightapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Screen that requests permission to send SMS notifications.
 * If permission is granted, a sample SMS is sent.
 * If denied, the user is informed but the rest of the app still works.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    private static final int REQUEST_SEND_SMS = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        Button btnAllowSms = findViewById(R.id.btnAllowSms);
        Button btnNoSms = findViewById(R.id.btnNoSms);

        btnAllowSms.setOnClickListener(view -> checkPermissionAndSend());
        btnNoSms.setOnClickListener(view -> {
            Toast.makeText(
                    this,
                    "You chose not to receive SMS alerts. The app will still work without them.",
                    Toast.LENGTH_LONG
            ).show();
        });
    }

    private void checkPermissionAndSend() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSampleSms();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQUEST_SEND_SMS
            );
        }
    }

    private void sendSampleSms() {
        // Emulator's default phone number; in a real app this would be configurable.
        String phoneNumber = "5554";
        String message = "Charity Weight App: this is an example SMS alert for your goal weight.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this,
                    "Example SMS sent (check your emulator's SMS).",
                    Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this,
                    "Unable to send SMS on this device/emulator.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSampleSms();
            } else {
                Toast.makeText(this,
                        "SMS permission denied. The app will continue without SMS alerts.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}


