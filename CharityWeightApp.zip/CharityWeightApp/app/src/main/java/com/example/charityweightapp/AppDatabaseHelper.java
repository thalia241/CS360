package com.example.charityweightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Central place to create and manage the app's SQLite database.
 * Tables:
 *  - users:   stores login accounts
 *  - weights: stores the daily weight entries that are shown in the grid
 */
public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "charity_weight.db";
    private static final int DATABASE_VERSION = 1;

    // --- Users table ---
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // --- Weights table ---
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_WEIGHT_ID = "_id";
    public static final String COL_WEIGHT_DATE = "entry_date";
    public static final String COL_WEIGHT_VALUE = "weight";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");"
        );

        // Create weights table
        db.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                        COL_WEIGHT_VALUE + " REAL NOT NULL" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // ----------------- USER METHODS -----------------

    /** Insert a new login account. Returns new row id, or -1 if error. */
    public long createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        return db.insert(TABLE_USERS, null, values);
    }

    /** Returns true if a row exists that matches username + password. */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = {COL_USER_ID};
        String selection = COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // ----------------- WEIGHT METHODS -----------------

    /** Insert a new weight entry for "today". */
    public long insertWeight(double weight) {
        SQLiteDatabase db = getWritableDatabase();

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(new Date());

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, today);
        values.put(COL_WEIGHT_VALUE, weight);

        return db.insert(TABLE_WEIGHTS, null, values);
    }

    /** Return all weight rows ordered by date, newest first. */
    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_WEIGHTS,
                null,
                null,
                null,
                null,
                null,
                COL_WEIGHT_DATE + " DESC"
        );
    }

    /** Update the weight value for a specific row id. */
    public int updateWeight(long id, double newWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_VALUE, newWeight);

        String where = COL_WEIGHT_ID + "=?";
        String[] whereArgs = {String.valueOf(id)};
        return db.update(TABLE_WEIGHTS, values, where, whereArgs);
    }

    /** Delete a row by id. */
    public int deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        String where = COL_WEIGHT_ID + "=?";
        String[] whereArgs = {String.valueOf(id)};
        return db.delete(TABLE_WEIGHTS, where, whereArgs);
    }
}



