package com.example.charityweightapp;

import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private GridView gridViewWeights;
    private EditText etWeightValue;
    private AppDatabaseHelper dbHelper;

    private ArrayList<Long> rowIds = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private long selectedWeightId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new AppDatabaseHelper(this);

        gridViewWeights = findViewById(R.id.gridViewWeights);
        etWeightValue = findViewById(R.id.etWeightValue);

        Button btnAdd = findViewById(R.id.btnAddEntry);
        Button btnUpdate = findViewById(R.id.btnUpdateEntry);
        Button btnDelete = findViewById(R.id.btnDeleteEntry);

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_activated_1,
                new ArrayList<>()
        );
        gridViewWeights.setAdapter(adapter);
        gridViewWeights.setChoiceMode(GridView.CHOICE_MODE_SINGLE);

        gridViewWeights.setOnItemClickListener((parent, view, position, id) -> {
            selectedWeightId = rowIds.get(position);
            String itemText = adapter.getItem(position);

            if (itemText != null) {
                int dashIndex = itemText.lastIndexOf("  -  ");
                if (dashIndex != -1) {
                    String weightPart = itemText.substring(dashIndex + 5)
                            .replace("lbs", "")
                            .trim();
                    etWeightValue.setText(weightPart);
                }
            }
        });

        btnAdd.setOnClickListener(v -> addWeight());
        btnUpdate.setOnClickListener(v -> updateWeight());
        btnDelete.setOnClickListener(v -> deleteWeight());

        refreshGrid();
    }

    private void addWeight() {
        String text = etWeightValue.getText().toString().trim();

        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "Enter a weight first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double value = Double.parseDouble(text);
            long rowId = dbHelper.insertWeight(value);

            if (rowId == -1) {
                Toast.makeText(this, "Could not insert weight.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Weight added.", Toast.LENGTH_SHORT).show();
                etWeightValue.setText("");
                selectedWeightId = -1;
                refreshGrid();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateWeight() {
        if (selectedWeightId == -1) {
            Toast.makeText(this, "Tap a row to update it.", Toast.LENGTH_SHORT).show();
            return;
        }

        String text = etWeightValue.getText().toString().trim();

        if (TextUtils.isEmpty(text)) {
            Toast.makeText(this, "Enter a new weight first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double newWeight = Double.parseDouble(text);
            int rows = dbHelper.updateWeight(selectedWeightId, newWeight);

            if (rows > 0) {
                Toast.makeText(this, "Updated.", Toast.LENGTH_SHORT).show();
                refreshGrid();
            } else {
                Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Weight must be numeric.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteWeight() {
        if (selectedWeightId == -1) {
            Toast.makeText(this, "Tap a row to delete.", Toast.LENGTH_SHORT).show();
            return;
        }

        int rows = dbHelper.deleteWeight(selectedWeightId);

        if (rows > 0) {
            Toast.makeText(this, "Deleted.", Toast.LENGTH_SHORT).show();
            etWeightValue.setText("");
            selectedWeightId = -1;
            refreshGrid();
        } else {
            Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshGrid() {
        rowIds.clear();
        adapter.clear();

        Cursor cursor = dbHelper.getAllWeights();

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_DATE));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_VALUE));

            rowIds.add(id);
            adapter.add(date + "  -  " + weight + " lbs");
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }
}






