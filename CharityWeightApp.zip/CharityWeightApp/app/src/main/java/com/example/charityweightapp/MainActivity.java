package com.example.charityweightapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Login screen.
 *  - Existing user: logs in and goes to DataDisplayActivity.
 *  - New user: creates an account and stores username/password in SQLite.
 *  - User can also open the SMS notification settings screen.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private AppDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new AppDatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);
        Button btnSmsSettings = findViewById(R.id.btnSmsSettings);

        btnLogin.setOnClickListener(view -> handleLogin());
        btnCreateAccount.setOnClickListener(view -> handleCreateAccount());

        // Open the screen that asks for SMS permission
        btnSmsSettings.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    /** Check username/password against the users table and open the grid screen if valid. */
    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean valid = dbHelper.validateUser(username, password);
        if (valid) {
            // Successful login – send username to the next screen
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    "Account not found. Please create a new account first.",
                    Toast.LENGTH_LONG).show();
        }
    }

    /** Create a new user row in the database. */
    private void handleCreateAccount() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Username and password are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        long rowId = dbHelper.createUser(username, password);
        if (rowId == -1) {
            Toast.makeText(this,
                    "That username is already taken. Please choose another.",
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this,
                    "Account created. You can now log in.",
                    Toast.LENGTH_LONG).show();
        }
    }
}




